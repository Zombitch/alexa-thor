const Alexa = require('ask-sdk-core');

const RollerShutterCloseHandler = {

  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest' || (request.type === 'IntentRequest' && request.intent.name === 'RollerShutterCloseIntent');
  },
  handle(handlerInput) {

    var options = {
      host: 'http://foo.com',
      port: 80,
      path: '/mypath',
      method: 'GET'
    };

    return handlerInput.responseBuilder.speak("It is done.").getResponse();
    /*return new Promise((resolve, reject) => {
     httpGet(options).then((response) => {
       resolve(handlerInput.responseBuilder.speak("It is done.").getResponse());
     }).catch((error) => {
        resolve(handlerInput.responseBuilder.speak('Thor is not available at the moment. Please try again later or contact your administrator.')
        .getResponse());
      });
    });*/
  },
};

const skillBuilder = Alexa.SkillBuilders.custom();
exports.handler = skillBuilder
  .addRequestHandlers(
    RollerShutterCloseHandler
  ).lambda();
